% number of digits for the generator's difficulties
getDiffLength(1,4).
getDiffLength(2,8).