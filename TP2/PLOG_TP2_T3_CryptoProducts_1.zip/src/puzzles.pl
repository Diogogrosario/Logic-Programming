% pre-loaded puzzle to test the solver.
puzzle(1,[R],[G,R],[B,G]).
puzzle(2,[B],[B,G],[R,R,R]).
puzzle(3,[G],[G,B],[B,R,G]).
puzzle(4,[R],[B,R],[B,G,B]).
puzzle(5,[B],[R,G],[R,R,G]).
puzzle(6,[G,R],[R,G],[R,B,R]).
puzzle(7,[R],[G,B],[B,G,G]).
puzzle(8,[B,R],[R,G],[G,B,G]).
puzzle(9,[G,B],[G,R],[R,B,B]).
puzzle(10,[R,B],[B,B],[G,R,G]).
puzzle(11,[B,G],[B,R],[G,B,R]).
puzzle(12,[G],[G,R],[R,G,G]).
puzzle(13,[R],[R,B],[G,B,G]).
puzzle(14,[B],[B,R],[G,R,R]).
puzzle(15,[G],[G,B],[B,B,R]).

% available colors for the puzzle generator
colors(['R','G','B','W','O','Y','P','C','M','T']).