In sicstus consult the file cryptoProduct.pl.
To execute the program in order to solve pre-loaded puzzles or randomly generate new ones use the predicate crypto_product/0.  
This will take you to menu where you can decide which you want.  
If you want to have a problem solved simply use the predicate crypto_user/3 which receives three lists corresponding to three numbers.